﻿ALTER TABLE [dbo].[EmployeeTbl]
ADD [Itcode] VARCHAR (50) NOT NULL DEFAULT 'DefaultValue';
