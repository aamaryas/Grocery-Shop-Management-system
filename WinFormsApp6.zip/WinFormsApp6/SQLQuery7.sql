﻿ALTER TABLE [dbo].[ItemTbl]
ADD [Itcode] VARCHAR (50) NOT NULL DEFAULT 'DefaultCode';
