﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using Microsoft.Data.SqlClient;

namespace WinFormsApp6
{

    public partial class items : Form
    {
        private SqlConnection Con;
        private int key = 0;
        public items()
        {

            InitializeComponent();
            Con = new SqlConnection(@"Data Source=(LocalDB)\MSSQLLocalDB;AttachDbFilename=C:\Users\amarx\Documents\amar.mdf;Integrated Security=True;Connect Timeout=30;Encrypt=True");

            DisplayItem();
        }

        private void items_Load(object sender, EventArgs e)
        {

        }

        private void button1_Click(object sender, EventArgs e)
        {
            if (string.IsNullOrEmpty(ItnameTb.Text) || string.IsNullOrEmpty(QtyTb.Text) || CatCb.SelectedIndex == -1 || string.IsNullOrEmpty(PriceTb.Text) || string.IsNullOrEmpty(ItcodeTb.Text))
            {
                MessageBox.Show("Missing Information");
            }
            else
            {
                try
                {
                    Con.Open();
                    string query = "INSERT INTO ItemTbl (ItName, ItQty, ItPrice, ItCat, Itcode) VALUES (@ItName, @ItQty, @ItPrice, @ItCat, @Itcode)";
                    SqlCommand cmd = new SqlCommand(query, Con);
                    cmd.Parameters.AddWithValue("@ItName", ItnameTb.Text);
                    cmd.Parameters.AddWithValue("@ItQty", QtyTb.Text);
                    cmd.Parameters.AddWithValue("@ItPrice", PriceTb.Text);
                    cmd.Parameters.AddWithValue("@ItCat", CatCb.SelectedItem.ToString());
                    cmd.Parameters.AddWithValue("@Itcode", ItcodeTb.Text);  // Add this line
                    cmd.ExecuteNonQuery();
                    MessageBox.Show("Item Saved Successfully");
                    Con.Close();
                    DisplayItem();
                    Clear();
                }
                catch (Exception ex)
                {
                    MessageBox.Show(ex.Message);
                }
            }
        }
        private void Clear()
        {
            ItnameTb.Text = "";
            QtyTb.Text = "";
            PriceTb.Text = "";
            CatCb.SelectedIndex = -1;
            ItcodeTb.Text = "";
        }
        private void button2_Click(object sender, EventArgs e)
        {
            if (string.IsNullOrEmpty(ItnameTb.Text) || string.IsNullOrEmpty(QtyTb.Text) || CatCb.SelectedIndex == -1 || string.IsNullOrEmpty(PriceTb.Text) || string.IsNullOrEmpty(ItcodeTb.Text))
            {
                MessageBox.Show("Missing Information");
            }
            else
            {
                try
                {
                    Con.Open();
                    string query = "UPDATE ItemTbl SET ItName=@ItName, ItQty=@ItQty, ItPrice=@ItPrice, ItCat=@ItCat, Itcode=@Itcode WHERE ItId=@ItId";
                    SqlCommand cmd = new SqlCommand(query, Con);
                    cmd.Parameters.AddWithValue("@ItName", ItnameTb.Text);
                    cmd.Parameters.AddWithValue("@ItQty", QtyTb.Text);
                    cmd.Parameters.AddWithValue("@ItPrice", PriceTb.Text);
                    cmd.Parameters.AddWithValue("@ItCat", CatCb.SelectedItem.ToString());
                    cmd.Parameters.AddWithValue("@Itcode", ItcodeTb.Text);  // Add this line
                    cmd.Parameters.AddWithValue("@ItId", key);
                    cmd.ExecuteNonQuery();
                    MessageBox.Show("Item Updated Successfully");
                    Con.Close();
                    DisplayItem();
                    Clear();
                }
                catch (Exception ex)
                {
                    MessageBox.Show(ex.Message);
                }
            }
        }
        private void DisplayItem()
        {
            Con.Open();
            string query = "SELECT * FROM ItemTbl";
            SqlCommand cmd = new SqlCommand(query, Con);
            SqlDataAdapter adapter = new SqlDataAdapter(cmd);
            DataSet ds = new DataSet();
            adapter.Fill(ds);
            ItemDGV.DataSource = ds.Tables[0];
            Con.Close();
        }
        private void button3_Click(object sender, EventArgs e)
        {
            if (key == 0)
            {
                MessageBox.Show("Select Item To Delete");
            }
            else
            {
                try
                {
                    Con.Open();
                    string query = "DELETE FROM ItemTbl WHERE ItId=@ItId";
                    SqlCommand cmd = new SqlCommand(query, Con);
                    cmd.Parameters.AddWithValue("@ItId", key);
                    cmd.ExecuteNonQuery();
                    MessageBox.Show("Item Deleted Successfully");
                    Con.Close();
                    DisplayItem();
                    Clear();
                }
                catch (Exception ex)
                {
                    MessageBox.Show(ex.Message);
                }
            }
        }

        private void button4_Click(object sender, EventArgs e)
        {
            Clear();
        }

        private void ItemDGV_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {
            if (e.RowIndex >= 0)
            {
                DataGridViewRow row = ItemDGV.Rows[e.RowIndex];
                ItnameTb.Text = row.Cells[1].Value.ToString();
                QtyTb.Text = row.Cells[2].Value.ToString();
                PriceTb.Text = row.Cells[3].Value.ToString();
                CatCb.SelectedItem = row.Cells[4].Value.ToString();
                ItcodeTb.Text = row.Cells[5].Value.ToString(); 

                if (string.IsNullOrEmpty(ItnameTb.Text))
                {
                    key = 0;
                }
                else
                {
                    key = Convert.ToInt32(row.Cells[0].Value.ToString());
                }
            }
        }

        private void label9_Click(object sender, EventArgs e)
        {
            Login Obj = new Login();

            Obj.Show();

            this.Hide();
        }

        private void label8_Click(object sender, EventArgs e)
        {

        }

        private void pictureBox2_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }

        private void label2_Click(object sender, EventArgs e)
        {
            Employees Obj = new Employees();

            Obj.Show();

            this.Hide();
        }

        private void panel2_Paint(object sender, PaintEventArgs e)
        {

        }
    }
}
