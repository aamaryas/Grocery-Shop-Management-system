﻿namespace WinFormsApp6
{
    partial class items
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(items));
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle4 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle5 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle6 = new System.Windows.Forms.DataGridViewCellStyle();
            panel1 = new System.Windows.Forms.Panel();
            pictureBox2 = new System.Windows.Forms.PictureBox();
            label1 = new System.Windows.Forms.Label();
            panel3 = new System.Windows.Forms.Panel();
            flowLayoutPanel1 = new System.Windows.Forms.FlowLayoutPanel();
            label8 = new System.Windows.Forms.Label();
            label2 = new System.Windows.Forms.Label();
            panel2 = new System.Windows.Forms.Panel();
            ItcodeTb = new System.Windows.Forms.TextBox();
            label10 = new System.Windows.Forms.Label();
            button2 = new System.Windows.Forms.Button();
            button1 = new System.Windows.Forms.Button();
            button4 = new System.Windows.Forms.Button();
            button3 = new System.Windows.Forms.Button();
            label6 = new System.Windows.Forms.Label();
            CatCb = new System.Windows.Forms.ComboBox();
            PriceTb = new System.Windows.Forms.TextBox();
            label5 = new System.Windows.Forms.Label();
            QtyTb = new System.Windows.Forms.TextBox();
            label4 = new System.Windows.Forms.Label();
            ItnameTb = new System.Windows.Forms.TextBox();
            label3 = new System.Windows.Forms.Label();
            ItemDGV = new Guna.UI2.WinForms.Guna2DataGridView();
            label7 = new System.Windows.Forms.Label();
            label9 = new System.Windows.Forms.Label();
            panel1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)pictureBox2).BeginInit();
            panel3.SuspendLayout();
            panel2.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)ItemDGV).BeginInit();
            SuspendLayout();
            // 
            // panel1
            // 
            panel1.BackColor = System.Drawing.Color.Tomato;
            panel1.Controls.Add(pictureBox2);
            panel1.Controls.Add(label1);
            panel1.Dock = System.Windows.Forms.DockStyle.Top;
            panel1.Location = new System.Drawing.Point(0, 0);
            panel1.Name = "panel1";
            panel1.Size = new System.Drawing.Size(1652, 120);
            panel1.TabIndex = 5;
            // 
            // pictureBox2
            // 
            pictureBox2.Image = (System.Drawing.Image)resources.GetObject("pictureBox2.Image");
            pictureBox2.Location = new System.Drawing.Point(1604, 0);
            pictureBox2.Name = "pictureBox2";
            pictureBox2.Size = new System.Drawing.Size(48, 43);
            pictureBox2.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            pictureBox2.TabIndex = 20;
            pictureBox2.TabStop = false;
            pictureBox2.Click += pictureBox2_Click;
            // 
            // label1
            // 
            label1.AutoSize = true;
            label1.Font = new System.Drawing.Font("Century Gothic", 18F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            label1.ForeColor = System.Drawing.Color.White;
            label1.Location = new System.Drawing.Point(527, 41);
            label1.Name = "label1";
            label1.Size = new System.Drawing.Size(489, 43);
            label1.TabIndex = 2;
            label1.Text = "GROCERY SHOP SOFTWARE";
            // 
            // panel3
            // 
            panel3.BackColor = System.Drawing.Color.Tomato;
            panel3.Controls.Add(flowLayoutPanel1);
            panel3.Location = new System.Drawing.Point(837, 169);
            panel3.Name = "panel3";
            panel3.Size = new System.Drawing.Size(80, 4);
            panel3.TabIndex = 20;
            // 
            // flowLayoutPanel1
            // 
            flowLayoutPanel1.Location = new System.Drawing.Point(166, 1);
            flowLayoutPanel1.Name = "flowLayoutPanel1";
            flowLayoutPanel1.Size = new System.Drawing.Size(300, 150);
            flowLayoutPanel1.TabIndex = 0;
            // 
            // label8
            // 
            label8.AutoSize = true;
            label8.Font = new System.Drawing.Font("Century Gothic", 14F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            label8.ForeColor = System.Drawing.Color.Red;
            label8.Location = new System.Drawing.Point(837, 132);
            label8.Name = "label8";
            label8.Size = new System.Drawing.Size(86, 34);
            label8.TabIndex = 22;
            label8.Text = "Items";
            label8.Click += label8_Click;
            // 
            // label2
            // 
            label2.AutoSize = true;
            label2.Font = new System.Drawing.Font("Century Gothic", 14F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            label2.ForeColor = System.Drawing.Color.Red;
            label2.Location = new System.Drawing.Point(544, 132);
            label2.Name = "label2";
            label2.Size = new System.Drawing.Size(161, 34);
            label2.TabIndex = 21;
            label2.Text = "Employees";
            label2.Click += label2_Click;
            // 
            // panel2
            // 
            panel2.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            panel2.Controls.Add(ItcodeTb);
            panel2.Controls.Add(label10);
            panel2.Controls.Add(button2);
            panel2.Controls.Add(button1);
            panel2.Controls.Add(button4);
            panel2.Controls.Add(button3);
            panel2.Controls.Add(label6);
            panel2.Controls.Add(CatCb);
            panel2.Controls.Add(PriceTb);
            panel2.Controls.Add(label5);
            panel2.Controls.Add(QtyTb);
            panel2.Controls.Add(label4);
            panel2.Controls.Add(ItnameTb);
            panel2.Controls.Add(label3);
            panel2.Location = new System.Drawing.Point(0, 202);
            panel2.Name = "panel2";
            panel2.Size = new System.Drawing.Size(1652, 266);
            panel2.TabIndex = 23;
            panel2.Paint += panel2_Paint;
            // 
            // ItcodeTb
            // 
            ItcodeTb.Location = new System.Drawing.Point(1227, 49);
            ItcodeTb.Name = "ItcodeTb";
            ItcodeTb.Size = new System.Drawing.Size(243, 31);
            ItcodeTb.TabIndex = 20;
            // 
            // label10
            // 
            label10.AutoSize = true;
            label10.Font = new System.Drawing.Font("Century Gothic", 14F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            label10.ForeColor = System.Drawing.Color.Red;
            label10.Location = new System.Drawing.Point(1227, 12);
            label10.Name = "label10";
            label10.Size = new System.Drawing.Size(161, 34);
            label10.TabIndex = 19;
            label10.Text = "Item Code";
            // 
            // button2
            // 
            button2.BackColor = System.Drawing.Color.Tomato;
            button2.FlatAppearance.BorderSize = 0;
            button2.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            button2.Font = new System.Drawing.Font("Century Gothic", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            button2.Location = new System.Drawing.Point(490, 153);
            button2.Name = "button2";
            button2.Size = new System.Drawing.Size(173, 60);
            button2.TabIndex = 18;
            button2.Text = "Edit";
            button2.UseVisualStyleBackColor = false;
            button2.Click += button2_Click;
            // 
            // button1
            // 
            button1.BackColor = System.Drawing.Color.Tomato;
            button1.FlatAppearance.BorderSize = 0;
            button1.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            button1.Font = new System.Drawing.Font("Century Gothic", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            button1.Location = new System.Drawing.Point(245, 153);
            button1.Name = "button1";
            button1.Size = new System.Drawing.Size(173, 60);
            button1.TabIndex = 17;
            button1.Text = "Save";
            button1.UseVisualStyleBackColor = false;
            button1.Click += button1_Click;
            // 
            // button4
            // 
            button4.BackColor = System.Drawing.Color.Tomato;
            button4.FlatAppearance.BorderSize = 0;
            button4.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            button4.Font = new System.Drawing.Font("Century Gothic", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            button4.Location = new System.Drawing.Point(993, 153);
            button4.Name = "button4";
            button4.Size = new System.Drawing.Size(173, 60);
            button4.TabIndex = 16;
            button4.Text = "Clear";
            button4.UseVisualStyleBackColor = false;
            button4.Click += button4_Click;
            // 
            // button3
            // 
            button3.BackColor = System.Drawing.Color.Tomato;
            button3.FlatAppearance.BorderSize = 0;
            button3.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            button3.Font = new System.Drawing.Font("Century Gothic", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            button3.Location = new System.Drawing.Point(737, 153);
            button3.Name = "button3";
            button3.Size = new System.Drawing.Size(173, 60);
            button3.TabIndex = 15;
            button3.Text = "Delete";
            button3.UseVisualStyleBackColor = false;
            button3.Click += button3_Click;
            // 
            // label6
            // 
            label6.AutoSize = true;
            label6.Font = new System.Drawing.Font("Century Gothic", 14F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            label6.ForeColor = System.Drawing.Color.Red;
            label6.Location = new System.Drawing.Point(927, 12);
            label6.Name = "label6";
            label6.Size = new System.Drawing.Size(166, 34);
            label6.TabIndex = 14;
            label6.Text = "Categories";
            // 
            // CatCb
            // 
            CatCb.FormattingEnabled = true;
            CatCb.Items.AddRange(new object[] { "FISH", "FRUIT", "VEGETABLE", "MEAT" });
            CatCb.Location = new System.Drawing.Point(927, 47);
            CatCb.Name = "CatCb";
            CatCb.Size = new System.Drawing.Size(226, 33);
            CatCb.TabIndex = 13;
            CatCb.Text = "Select Category";
            // 
            // PriceTb
            // 
            PriceTb.Location = new System.Drawing.Point(626, 49);
            PriceTb.Name = "PriceTb";
            PriceTb.Size = new System.Drawing.Size(243, 31);
            PriceTb.TabIndex = 12;
            // 
            // label5
            // 
            label5.AutoSize = true;
            label5.Font = new System.Drawing.Font("Century Gothic", 14F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            label5.ForeColor = System.Drawing.Color.Red;
            label5.Location = new System.Drawing.Point(626, 12);
            label5.Name = "label5";
            label5.Size = new System.Drawing.Size(83, 34);
            label5.TabIndex = 11;
            label5.Text = "Price";
            // 
            // QtyTb
            // 
            QtyTb.Location = new System.Drawing.Point(324, 49);
            QtyTb.Name = "QtyTb";
            QtyTb.Size = new System.Drawing.Size(243, 31);
            QtyTb.TabIndex = 10;
            // 
            // label4
            // 
            label4.AutoSize = true;
            label4.Font = new System.Drawing.Font("Century Gothic", 14F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            label4.ForeColor = System.Drawing.Color.Red;
            label4.Location = new System.Drawing.Point(333, 12);
            label4.Name = "label4";
            label4.Size = new System.Drawing.Size(134, 34);
            label4.TabIndex = 9;
            label4.Text = "Quantity";
            // 
            // ItnameTb
            // 
            ItnameTb.Location = new System.Drawing.Point(29, 49);
            ItnameTb.Name = "ItnameTb";
            ItnameTb.Size = new System.Drawing.Size(243, 31);
            ItnameTb.TabIndex = 8;
            // 
            // label3
            // 
            label3.AutoSize = true;
            label3.Font = new System.Drawing.Font("Century Gothic", 14F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            label3.ForeColor = System.Drawing.Color.Red;
            label3.Location = new System.Drawing.Point(29, 12);
            label3.Name = "label3";
            label3.Size = new System.Drawing.Size(167, 34);
            label3.TabIndex = 5;
            label3.Text = "Item Name";
            // 
            // ItemDGV
            // 
            dataGridViewCellStyle4.BackColor = System.Drawing.Color.White;
            ItemDGV.AlternatingRowsDefaultCellStyle = dataGridViewCellStyle4;
            ItemDGV.BackgroundColor = System.Drawing.SystemColors.Control;
            dataGridViewCellStyle5.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle5.BackColor = System.Drawing.Color.FromArgb(100, 88, 255);
            dataGridViewCellStyle5.Font = new System.Drawing.Font("Segoe UI", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            dataGridViewCellStyle5.ForeColor = System.Drawing.Color.White;
            dataGridViewCellStyle5.SelectionBackColor = System.Drawing.SystemColors.Highlight;
            dataGridViewCellStyle5.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle5.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            ItemDGV.ColumnHeadersDefaultCellStyle = dataGridViewCellStyle5;
            ItemDGV.ColumnHeadersHeight = 27;
            ItemDGV.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.EnableResizing;
            dataGridViewCellStyle6.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle6.BackColor = System.Drawing.Color.White;
            dataGridViewCellStyle6.Font = new System.Drawing.Font("Segoe UI", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            dataGridViewCellStyle6.ForeColor = System.Drawing.Color.FromArgb(71, 69, 94);
            dataGridViewCellStyle6.SelectionBackColor = System.Drawing.Color.FromArgb(231, 229, 255);
            dataGridViewCellStyle6.SelectionForeColor = System.Drawing.Color.FromArgb(71, 69, 94);
            dataGridViewCellStyle6.WrapMode = System.Windows.Forms.DataGridViewTriState.False;
            ItemDGV.DefaultCellStyle = dataGridViewCellStyle6;
            ItemDGV.GridColor = System.Drawing.Color.FromArgb(231, 229, 255);
            ItemDGV.Location = new System.Drawing.Point(74, 530);
            ItemDGV.Name = "ItemDGV";
            ItemDGV.RowHeadersVisible = false;
            ItemDGV.RowHeadersWidth = 62;
            ItemDGV.RowTemplate.Height = 33;
            ItemDGV.Size = new System.Drawing.Size(1490, 324);
            ItemDGV.TabIndex = 25;
            ItemDGV.ThemeStyle.AlternatingRowsStyle.BackColor = System.Drawing.Color.White;
            ItemDGV.ThemeStyle.AlternatingRowsStyle.Font = null;
            ItemDGV.ThemeStyle.AlternatingRowsStyle.ForeColor = System.Drawing.Color.Empty;
            ItemDGV.ThemeStyle.AlternatingRowsStyle.SelectionBackColor = System.Drawing.Color.Empty;
            ItemDGV.ThemeStyle.AlternatingRowsStyle.SelectionForeColor = System.Drawing.Color.Empty;
            ItemDGV.ThemeStyle.BackColor = System.Drawing.SystemColors.Control;
            ItemDGV.ThemeStyle.GridColor = System.Drawing.Color.FromArgb(231, 229, 255);
            ItemDGV.ThemeStyle.HeaderStyle.BackColor = System.Drawing.Color.Tomato;
            ItemDGV.ThemeStyle.HeaderStyle.BorderStyle = System.Windows.Forms.DataGridViewHeaderBorderStyle.None;
            ItemDGV.ThemeStyle.HeaderStyle.Font = new System.Drawing.Font("Century Gothic", 14F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            ItemDGV.ThemeStyle.HeaderStyle.ForeColor = System.Drawing.Color.White;
            ItemDGV.ThemeStyle.HeaderStyle.HeaightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.EnableResizing;
            ItemDGV.ThemeStyle.HeaderStyle.Height = 27;
            ItemDGV.ThemeStyle.ReadOnly = false;
            ItemDGV.ThemeStyle.RowsStyle.BackColor = System.Drawing.Color.White;
            ItemDGV.ThemeStyle.RowsStyle.BorderStyle = System.Windows.Forms.DataGridViewCellBorderStyle.SingleHorizontal;
            ItemDGV.ThemeStyle.RowsStyle.Font = new System.Drawing.Font("Segoe UI", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            ItemDGV.ThemeStyle.RowsStyle.ForeColor = System.Drawing.Color.FromArgb(71, 69, 94);
            ItemDGV.ThemeStyle.RowsStyle.Height = 33;
            ItemDGV.ThemeStyle.RowsStyle.SelectionBackColor = System.Drawing.Color.FromArgb(231, 229, 255);
            ItemDGV.ThemeStyle.RowsStyle.SelectionForeColor = System.Drawing.Color.FromArgb(71, 69, 94);
            ItemDGV.CellContentClick += ItemDGV_CellContentClick;
            // 
            // label7
            // 
            label7.AutoSize = true;
            label7.Font = new System.Drawing.Font("Century Gothic", 14F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            label7.ForeColor = System.Drawing.Color.Red;
            label7.Location = new System.Drawing.Point(655, 483);
            label7.Name = "label7";
            label7.Size = new System.Drawing.Size(89, 34);
            label7.TabIndex = 24;
            label7.Text = "Stock";
            // 
            // label9
            // 
            label9.AutoSize = true;
            label9.BackColor = System.Drawing.Color.Tomato;
            label9.Font = new System.Drawing.Font("Century Gothic", 14F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            label9.ForeColor = System.Drawing.Color.Black;
            label9.Location = new System.Drawing.Point(1530, 885);
            label9.Name = "label9";
            label9.Size = new System.Drawing.Size(110, 34);
            label9.TabIndex = 38;
            label9.Text = "Logout";
            label9.Click += label9_Click;
            // 
            // items
            // 
            AutoScaleDimensions = new System.Drawing.SizeF(10F, 25F);
            AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            ClientSize = new System.Drawing.Size(1652, 928);
            Controls.Add(label9);
            Controls.Add(ItemDGV);
            Controls.Add(label7);
            Controls.Add(panel2);
            Controls.Add(panel3);
            Controls.Add(label8);
            Controls.Add(label2);
            Controls.Add(panel1);
            FormBorderStyle = System.Windows.Forms.FormBorderStyle.None;
            Name = "items";
            StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            Text = "items";
            Load += items_Load;
            panel1.ResumeLayout(false);
            panel1.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)pictureBox2).EndInit();
            panel3.ResumeLayout(false);
            panel2.ResumeLayout(false);
            panel2.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)ItemDGV).EndInit();
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.PictureBox pictureBox2;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Panel panel3;
        private System.Windows.Forms.FlowLayoutPanel flowLayoutPanel1;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Panel panel2;
        private System.Windows.Forms.TextBox ItcodeTb;
        private System.Windows.Forms.Label label10;
        private System.Windows.Forms.Button button2;
        private System.Windows.Forms.Button button1;
        private System.Windows.Forms.Button button4;
        private System.Windows.Forms.Button button3;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.ComboBox CatCb;
        private System.Windows.Forms.TextBox PriceTb;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.TextBox QtyTb;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.TextBox ItnameTb;
        private System.Windows.Forms.Label label3;
        private Guna.UI2.WinForms.Guna2DataGridView ItemDGV;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.Label label9;
    }
}