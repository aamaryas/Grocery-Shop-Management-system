﻿namespace WinFormsApp6
{
    internal class Amount
    {
    }
}