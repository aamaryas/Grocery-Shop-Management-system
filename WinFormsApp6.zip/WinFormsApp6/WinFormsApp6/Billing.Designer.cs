﻿namespace WinFormsApp6
{
    partial class Billing
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Billing));
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle1 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle2 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle3 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle4 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle5 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle6 = new System.Windows.Forms.DataGridViewCellStyle();
            panel1 = new System.Windows.Forms.Panel();
            EmployeeLbl = new System.Windows.Forms.Label();
            label2 = new System.Windows.Forms.Label();
            pictureBox1 = new System.Windows.Forms.PictureBox();
            label1 = new System.Windows.Forms.Label();
            panel3 = new System.Windows.Forms.Panel();
            flowLayoutPanel1 = new System.Windows.Forms.FlowLayoutPanel();
            BillDGV = new Guna.UI2.WinForms.Guna2DataGridView();
            Column1 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            Column2 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            Column3 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            Column4 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            Column5 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            label8 = new System.Windows.Forms.Label();
            panel2 = new System.Windows.Forms.Panel();
            ClientNameTb = new System.Windows.Forms.TextBox();
            label6 = new System.Windows.Forms.Label();
            ItPriceTb = new System.Windows.Forms.TextBox();
            label5 = new System.Windows.Forms.Label();
            ResetBtn = new System.Windows.Forms.Button();
            AddToBillBtn = new System.Windows.Forms.Button();
            ItQtyTb = new System.Windows.Forms.TextBox();
            label4 = new System.Windows.Forms.Label();
            ItNameTb = new System.Windows.Forms.TextBox();
            label3 = new System.Windows.Forms.Label();
            label7 = new System.Windows.Forms.Label();
            label9 = new System.Windows.Forms.Label();
            ItemDGV = new Guna.UI2.WinForms.Guna2DataGridView();
            TotalLbl = new System.Windows.Forms.Label();
            button1 = new System.Windows.Forms.Button();
            printDocument1 = new System.Drawing.Printing.PrintDocument();
            printPreviewDialog1 = new System.Windows.Forms.PrintPreviewDialog();
            panel1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)pictureBox1).BeginInit();
            panel3.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)BillDGV).BeginInit();
            panel2.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)ItemDGV).BeginInit();
            SuspendLayout();
            // 
            // panel1
            // 
            panel1.BackColor = System.Drawing.Color.Tomato;
            panel1.Controls.Add(EmployeeLbl);
            panel1.Controls.Add(label2);
            panel1.Controls.Add(pictureBox1);
            panel1.Controls.Add(label1);
            panel1.Dock = System.Windows.Forms.DockStyle.Top;
            panel1.Location = new System.Drawing.Point(0, 0);
            panel1.Name = "panel1";
            panel1.Size = new System.Drawing.Size(1652, 120);
            panel1.TabIndex = 3;
            // 
            // EmployeeLbl
            // 
            EmployeeLbl.AutoSize = true;
            EmployeeLbl.BackColor = System.Drawing.Color.Tomato;
            EmployeeLbl.Font = new System.Drawing.Font("Century Gothic", 14F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            EmployeeLbl.ForeColor = System.Drawing.Color.Black;
            EmployeeLbl.Location = new System.Drawing.Point(1486, 9);
            EmployeeLbl.Name = "EmployeeLbl";
            EmployeeLbl.Size = new System.Drawing.Size(69, 34);
            EmployeeLbl.TabIndex = 36;
            EmployeeLbl.Text = "User";
            EmployeeLbl.Click += EmployeeLbl_Click;
            // 
            // label2
            // 
            label2.AutoSize = true;
            label2.Font = new System.Drawing.Font("Century Gothic", 14F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            label2.ForeColor = System.Drawing.Color.Red;
            label2.Location = new System.Drawing.Point(1044, -148);
            label2.Name = "label2";
            label2.Size = new System.Drawing.Size(211, 34);
            label2.TabIndex = 9;
            label2.Text = "Manage Items";
            // 
            // pictureBox1
            // 
            pictureBox1.BackColor = System.Drawing.Color.Salmon;
            pictureBox1.Image = (System.Drawing.Image)resources.GetObject("pictureBox1.Image");
            pictureBox1.Location = new System.Drawing.Point(1601, 0);
            pictureBox1.Name = "pictureBox1";
            pictureBox1.Size = new System.Drawing.Size(51, 43);
            pictureBox1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            pictureBox1.TabIndex = 8;
            pictureBox1.TabStop = false;
            pictureBox1.Click += pictureBox1_Click;
            // 
            // label1
            // 
            label1.AutoSize = true;
            label1.Font = new System.Drawing.Font("Century Gothic", 18F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            label1.ForeColor = System.Drawing.Color.White;
            label1.Location = new System.Drawing.Point(529, 26);
            label1.Name = "label1";
            label1.Size = new System.Drawing.Size(489, 43);
            label1.TabIndex = 2;
            label1.Text = "GROCERY SHOP SOFTWARE";
            // 
            // panel3
            // 
            panel3.BackColor = System.Drawing.Color.Tomato;
            panel3.Controls.Add(flowLayoutPanel1);
            panel3.Location = new System.Drawing.Point(683, 161);
            panel3.Name = "panel3";
            panel3.Size = new System.Drawing.Size(80, 4);
            panel3.TabIndex = 40;
            // 
            // flowLayoutPanel1
            // 
            flowLayoutPanel1.Location = new System.Drawing.Point(166, 1);
            flowLayoutPanel1.Name = "flowLayoutPanel1";
            flowLayoutPanel1.Size = new System.Drawing.Size(300, 150);
            flowLayoutPanel1.TabIndex = 0;
            // 
            // BillDGV
            // 
            dataGridViewCellStyle1.BackColor = System.Drawing.Color.White;
            BillDGV.AlternatingRowsDefaultCellStyle = dataGridViewCellStyle1;
            dataGridViewCellStyle2.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle2.BackColor = System.Drawing.Color.Tomato;
            dataGridViewCellStyle2.Font = new System.Drawing.Font("Century Gothic", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            dataGridViewCellStyle2.ForeColor = System.Drawing.Color.White;
            dataGridViewCellStyle2.SelectionBackColor = System.Drawing.SystemColors.Highlight;
            dataGridViewCellStyle2.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle2.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            BillDGV.ColumnHeadersDefaultCellStyle = dataGridViewCellStyle2;
            BillDGV.ColumnHeadersHeight = 32;
            BillDGV.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.EnableResizing;
            BillDGV.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] { Column1, Column2, Column3, Column4, Column5 });
            dataGridViewCellStyle3.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle3.BackColor = System.Drawing.Color.White;
            dataGridViewCellStyle3.Font = new System.Drawing.Font("Segoe UI", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            dataGridViewCellStyle3.ForeColor = System.Drawing.Color.FromArgb(71, 69, 94);
            dataGridViewCellStyle3.SelectionBackColor = System.Drawing.Color.FromArgb(231, 229, 255);
            dataGridViewCellStyle3.SelectionForeColor = System.Drawing.Color.FromArgb(71, 69, 94);
            dataGridViewCellStyle3.WrapMode = System.Windows.Forms.DataGridViewTriState.False;
            BillDGV.DefaultCellStyle = dataGridViewCellStyle3;
            BillDGV.GridColor = System.Drawing.Color.FromArgb(231, 229, 255);
            BillDGV.Location = new System.Drawing.Point(934, 205);
            BillDGV.Name = "BillDGV";
            BillDGV.RowHeadersVisible = false;
            BillDGV.RowHeadersWidth = 62;
            BillDGV.RowTemplate.Height = 33;
            BillDGV.Size = new System.Drawing.Size(673, 335);
            BillDGV.TabIndex = 39;
            BillDGV.ThemeStyle.AlternatingRowsStyle.BackColor = System.Drawing.Color.White;
            BillDGV.ThemeStyle.AlternatingRowsStyle.Font = null;
            BillDGV.ThemeStyle.AlternatingRowsStyle.ForeColor = System.Drawing.Color.Empty;
            BillDGV.ThemeStyle.AlternatingRowsStyle.SelectionBackColor = System.Drawing.Color.Empty;
            BillDGV.ThemeStyle.AlternatingRowsStyle.SelectionForeColor = System.Drawing.Color.Empty;
            BillDGV.ThemeStyle.BackColor = System.Drawing.Color.White;
            BillDGV.ThemeStyle.GridColor = System.Drawing.Color.FromArgb(231, 229, 255);
            BillDGV.ThemeStyle.HeaderStyle.BackColor = System.Drawing.Color.Tomato;
            BillDGV.ThemeStyle.HeaderStyle.BorderStyle = System.Windows.Forms.DataGridViewHeaderBorderStyle.None;
            BillDGV.ThemeStyle.HeaderStyle.Font = new System.Drawing.Font("Century Gothic", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            BillDGV.ThemeStyle.HeaderStyle.ForeColor = System.Drawing.Color.White;
            BillDGV.ThemeStyle.HeaderStyle.HeaightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.EnableResizing;
            BillDGV.ThemeStyle.HeaderStyle.Height = 32;
            BillDGV.ThemeStyle.ReadOnly = false;
            BillDGV.ThemeStyle.RowsStyle.BackColor = System.Drawing.Color.White;
            BillDGV.ThemeStyle.RowsStyle.BorderStyle = System.Windows.Forms.DataGridViewCellBorderStyle.SingleHorizontal;
            BillDGV.ThemeStyle.RowsStyle.Font = new System.Drawing.Font("Segoe UI", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            BillDGV.ThemeStyle.RowsStyle.ForeColor = System.Drawing.Color.FromArgb(71, 69, 94);
            BillDGV.ThemeStyle.RowsStyle.Height = 33;
            BillDGV.ThemeStyle.RowsStyle.SelectionBackColor = System.Drawing.Color.FromArgb(231, 229, 255);
            BillDGV.ThemeStyle.RowsStyle.SelectionForeColor = System.Drawing.Color.FromArgb(71, 69, 94);
            BillDGV.CellContentClick += BillDGV_CellContentClick;
            // 
            // Column1
            // 
            Column1.HeaderText = "ID";
            Column1.MinimumWidth = 8;
            Column1.Name = "Column1";
            // 
            // Column2
            // 
            Column2.HeaderText = "Items";
            Column2.MinimumWidth = 8;
            Column2.Name = "Column2";
            // 
            // Column3
            // 
            Column3.HeaderText = "Price";
            Column3.MinimumWidth = 8;
            Column3.Name = "Column3";
            // 
            // Column4
            // 
            Column4.HeaderText = "Quantity";
            Column4.MinimumWidth = 8;
            Column4.Name = "Column4";
            // 
            // Column5
            // 
            Column5.HeaderText = "Total";
            Column5.MinimumWidth = 8;
            Column5.Name = "Column5";
            // 
            // label8
            // 
            label8.AutoSize = true;
            label8.Font = new System.Drawing.Font("Century Gothic", 14F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            label8.ForeColor = System.Drawing.Color.Red;
            label8.Location = new System.Drawing.Point(226, 543);
            label8.Name = "label8";
            label8.Size = new System.Drawing.Size(135, 34);
            label8.TabIndex = 38;
            label8.Text = "Items List";
            // 
            // panel2
            // 
            panel2.Controls.Add(ClientNameTb);
            panel2.Controls.Add(label6);
            panel2.Controls.Add(ItPriceTb);
            panel2.Controls.Add(label5);
            panel2.Controls.Add(ResetBtn);
            panel2.Controls.Add(AddToBillBtn);
            panel2.Controls.Add(ItQtyTb);
            panel2.Controls.Add(label4);
            panel2.Controls.Add(ItNameTb);
            panel2.Controls.Add(label3);
            panel2.Location = new System.Drawing.Point(36, 205);
            panel2.Name = "panel2";
            panel2.Size = new System.Drawing.Size(604, 335);
            panel2.TabIndex = 37;
            // 
            // ClientNameTb
            // 
            ClientNameTb.Location = new System.Drawing.Point(33, 162);
            ClientNameTb.Name = "ClientNameTb";
            ClientNameTb.Size = new System.Drawing.Size(243, 31);
            ClientNameTb.TabIndex = 28;
            // 
            // label6
            // 
            label6.AutoSize = true;
            label6.Font = new System.Drawing.Font("Century Gothic", 14F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            label6.ForeColor = System.Drawing.Color.Red;
            label6.Location = new System.Drawing.Point(33, 119);
            label6.Name = "label6";
            label6.Size = new System.Drawing.Size(188, 34);
            label6.TabIndex = 27;
            label6.Text = "Client Name";
            // 
            // ItPriceTb
            // 
            ItPriceTb.Enabled = false;
            ItPriceTb.Location = new System.Drawing.Point(352, 162);
            ItPriceTb.Name = "ItPriceTb";
            ItPriceTb.Size = new System.Drawing.Size(243, 31);
            ItPriceTb.TabIndex = 26;
            // 
            // label5
            // 
            label5.AutoSize = true;
            label5.Font = new System.Drawing.Font("Century Gothic", 14F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            label5.ForeColor = System.Drawing.Color.Red;
            label5.Location = new System.Drawing.Point(352, 119);
            label5.Name = "label5";
            label5.Size = new System.Drawing.Size(83, 34);
            label5.TabIndex = 25;
            label5.Text = "Price";
            // 
            // ResetBtn
            // 
            ResetBtn.BackColor = System.Drawing.Color.Tomato;
            ResetBtn.FlatAppearance.BorderSize = 0;
            ResetBtn.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            ResetBtn.Font = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            ResetBtn.Location = new System.Drawing.Point(352, 259);
            ResetBtn.Name = "ResetBtn";
            ResetBtn.Size = new System.Drawing.Size(173, 60);
            ResetBtn.TabIndex = 24;
            ResetBtn.Text = "Reset";
            ResetBtn.UseVisualStyleBackColor = false;
            ResetBtn.Click += ResetBtn_Click;
            // 
            // AddToBillBtn
            // 
            AddToBillBtn.BackColor = System.Drawing.Color.Tomato;
            AddToBillBtn.FlatAppearance.BorderSize = 0;
            AddToBillBtn.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            AddToBillBtn.Font = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            AddToBillBtn.Location = new System.Drawing.Point(48, 259);
            AddToBillBtn.Name = "AddToBillBtn";
            AddToBillBtn.Size = new System.Drawing.Size(173, 60);
            AddToBillBtn.TabIndex = 23;
            AddToBillBtn.Text = "Add To Bill";
            AddToBillBtn.UseVisualStyleBackColor = false;
            AddToBillBtn.Click += AddToBillBtn_Click;
            // 
            // ItQtyTb
            // 
            ItQtyTb.Location = new System.Drawing.Point(352, 66);
            ItQtyTb.Name = "ItQtyTb";
            ItQtyTb.Size = new System.Drawing.Size(243, 31);
            ItQtyTb.TabIndex = 22;
            // 
            // label4
            // 
            label4.AutoSize = true;
            label4.Font = new System.Drawing.Font("Century Gothic", 14F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            label4.ForeColor = System.Drawing.Color.Red;
            label4.Location = new System.Drawing.Point(352, 23);
            label4.Name = "label4";
            label4.Size = new System.Drawing.Size(134, 34);
            label4.TabIndex = 21;
            label4.Text = "Quantity";
            // 
            // ItNameTb
            // 
            ItNameTb.Enabled = false;
            ItNameTb.Location = new System.Drawing.Point(33, 66);
            ItNameTb.Name = "ItNameTb";
            ItNameTb.Size = new System.Drawing.Size(243, 31);
            ItNameTb.TabIndex = 20;
            // 
            // label3
            // 
            label3.AutoSize = true;
            label3.Font = new System.Drawing.Font("Century Gothic", 14F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            label3.ForeColor = System.Drawing.Color.Red;
            label3.Location = new System.Drawing.Point(33, 23);
            label3.Name = "label3";
            label3.Size = new System.Drawing.Size(167, 34);
            label3.TabIndex = 19;
            label3.Text = "Item Name";
            // 
            // label7
            // 
            label7.AutoSize = true;
            label7.Font = new System.Drawing.Font("Century Gothic", 14F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            label7.ForeColor = System.Drawing.Color.Red;
            label7.Location = new System.Drawing.Point(674, 124);
            label7.Name = "label7";
            label7.Size = new System.Drawing.Size(101, 34);
            label7.TabIndex = 36;
            label7.Text = "Billing ";
            // 
            // label9
            // 
            label9.AutoSize = true;
            label9.BackColor = System.Drawing.Color.Tomato;
            label9.Font = new System.Drawing.Font("Century Gothic", 14F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            label9.ForeColor = System.Drawing.Color.Black;
            label9.Location = new System.Drawing.Point(1525, 894);
            label9.Name = "label9";
            label9.Size = new System.Drawing.Size(110, 34);
            label9.TabIndex = 44;
            label9.Text = "Logout";
            label9.Click += label9_Click;
            // 
            // ItemDGV
            // 
            dataGridViewCellStyle4.BackColor = System.Drawing.Color.White;
            ItemDGV.AlternatingRowsDefaultCellStyle = dataGridViewCellStyle4;
            ItemDGV.BackgroundColor = System.Drawing.SystemColors.Control;
            dataGridViewCellStyle5.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle5.BackColor = System.Drawing.Color.FromArgb(100, 88, 255);
            dataGridViewCellStyle5.Font = new System.Drawing.Font("Segoe UI", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            dataGridViewCellStyle5.ForeColor = System.Drawing.Color.White;
            dataGridViewCellStyle5.SelectionBackColor = System.Drawing.SystemColors.Highlight;
            dataGridViewCellStyle5.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle5.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            ItemDGV.ColumnHeadersDefaultCellStyle = dataGridViewCellStyle5;
            ItemDGV.ColumnHeadersHeight = 27;
            ItemDGV.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.EnableResizing;
            dataGridViewCellStyle6.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle6.BackColor = System.Drawing.Color.White;
            dataGridViewCellStyle6.Font = new System.Drawing.Font("Segoe UI", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            dataGridViewCellStyle6.ForeColor = System.Drawing.Color.FromArgb(71, 69, 94);
            dataGridViewCellStyle6.SelectionBackColor = System.Drawing.Color.FromArgb(231, 229, 255);
            dataGridViewCellStyle6.SelectionForeColor = System.Drawing.Color.FromArgb(71, 69, 94);
            dataGridViewCellStyle6.WrapMode = System.Windows.Forms.DataGridViewTriState.False;
            ItemDGV.DefaultCellStyle = dataGridViewCellStyle6;
            ItemDGV.GridColor = System.Drawing.Color.FromArgb(231, 229, 255);
            ItemDGV.Location = new System.Drawing.Point(36, 587);
            ItemDGV.Name = "ItemDGV";
            ItemDGV.RowHeadersVisible = false;
            ItemDGV.RowHeadersWidth = 62;
            ItemDGV.RowTemplate.Height = 33;
            ItemDGV.Size = new System.Drawing.Size(757, 341);
            ItemDGV.TabIndex = 43;
            ItemDGV.ThemeStyle.AlternatingRowsStyle.BackColor = System.Drawing.Color.White;
            ItemDGV.ThemeStyle.AlternatingRowsStyle.Font = null;
            ItemDGV.ThemeStyle.AlternatingRowsStyle.ForeColor = System.Drawing.Color.Empty;
            ItemDGV.ThemeStyle.AlternatingRowsStyle.SelectionBackColor = System.Drawing.Color.Empty;
            ItemDGV.ThemeStyle.AlternatingRowsStyle.SelectionForeColor = System.Drawing.Color.Empty;
            ItemDGV.ThemeStyle.BackColor = System.Drawing.SystemColors.Control;
            ItemDGV.ThemeStyle.GridColor = System.Drawing.Color.FromArgb(231, 229, 255);
            ItemDGV.ThemeStyle.HeaderStyle.BackColor = System.Drawing.Color.Tomato;
            ItemDGV.ThemeStyle.HeaderStyle.BorderStyle = System.Windows.Forms.DataGridViewHeaderBorderStyle.None;
            ItemDGV.ThemeStyle.HeaderStyle.Font = new System.Drawing.Font("Century Gothic", 14F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            ItemDGV.ThemeStyle.HeaderStyle.ForeColor = System.Drawing.Color.White;
            ItemDGV.ThemeStyle.HeaderStyle.HeaightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.EnableResizing;
            ItemDGV.ThemeStyle.HeaderStyle.Height = 27;
            ItemDGV.ThemeStyle.ReadOnly = false;
            ItemDGV.ThemeStyle.RowsStyle.BackColor = System.Drawing.Color.White;
            ItemDGV.ThemeStyle.RowsStyle.BorderStyle = System.Windows.Forms.DataGridViewCellBorderStyle.SingleHorizontal;
            ItemDGV.ThemeStyle.RowsStyle.Font = new System.Drawing.Font("Segoe UI", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            ItemDGV.ThemeStyle.RowsStyle.ForeColor = System.Drawing.Color.FromArgb(71, 69, 94);
            ItemDGV.ThemeStyle.RowsStyle.Height = 33;
            ItemDGV.ThemeStyle.RowsStyle.SelectionBackColor = System.Drawing.Color.FromArgb(231, 229, 255);
            ItemDGV.ThemeStyle.RowsStyle.SelectionForeColor = System.Drawing.Color.FromArgb(71, 69, 94);
            ItemDGV.CellContentClick += ItemDGV_CellContentClick;
            // 
            // TotalLbl
            // 
            TotalLbl.AutoSize = true;
            TotalLbl.Font = new System.Drawing.Font("Century Gothic", 14F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            TotalLbl.ForeColor = System.Drawing.Color.Red;
            TotalLbl.Location = new System.Drawing.Point(1315, 634);
            TotalLbl.Name = "TotalLbl";
            TotalLbl.Size = new System.Drawing.Size(78, 34);
            TotalLbl.TabIndex = 42;
            TotalLbl.Text = "total";
            // 
            // button1
            // 
            button1.BackColor = System.Drawing.Color.Tomato;
            button1.FlatAppearance.BorderSize = 0;
            button1.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            button1.Font = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            button1.Location = new System.Drawing.Point(1266, 688);
            button1.Name = "button1";
            button1.Size = new System.Drawing.Size(173, 60);
            button1.TabIndex = 41;
            button1.Text = "Print";
            button1.UseVisualStyleBackColor = false;
            button1.Click += button1_Click;
            // 
            // printDocument1
            // 
            printDocument1.PrintPage += printDocument1_PrintPage;
            // 
            // printPreviewDialog1
            // 
            printPreviewDialog1.AutoScrollMargin = new System.Drawing.Size(0, 0);
            printPreviewDialog1.AutoScrollMinSize = new System.Drawing.Size(0, 0);
            printPreviewDialog1.ClientSize = new System.Drawing.Size(400, 300);
            printPreviewDialog1.Enabled = true;
            printPreviewDialog1.Icon = (System.Drawing.Icon)resources.GetObject("printPreviewDialog1.Icon");
            printPreviewDialog1.Name = "printPreviewDialog1";
            printPreviewDialog1.Visible = false;
            printPreviewDialog1.Load += printPreviewDialog1_Load;
            // 
            // Billing
            // 
            AutoScaleDimensions = new System.Drawing.SizeF(10F, 25F);
            AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            ClientSize = new System.Drawing.Size(1652, 940);
            Controls.Add(label9);
            Controls.Add(ItemDGV);
            Controls.Add(TotalLbl);
            Controls.Add(button1);
            Controls.Add(panel3);
            Controls.Add(BillDGV);
            Controls.Add(label8);
            Controls.Add(panel2);
            Controls.Add(label7);
            Controls.Add(panel1);
            FormBorderStyle = System.Windows.Forms.FormBorderStyle.None;
            Name = "Billing";
            StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            Text = "Billing";
            Load += Billing_Load;
            panel1.ResumeLayout(false);
            panel1.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)pictureBox1).EndInit();
            panel3.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)BillDGV).EndInit();
            panel2.ResumeLayout(false);
            panel2.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)ItemDGV).EndInit();
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.Label EmployeeLbl;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.PictureBox pictureBox1;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Panel panel3;
        private System.Windows.Forms.FlowLayoutPanel flowLayoutPanel1;
        private Guna.UI2.WinForms.Guna2DataGridView BillDGV;
        private System.Windows.Forms.DataGridViewTextBoxColumn Column1;
        private System.Windows.Forms.DataGridViewTextBoxColumn Column2;
        private System.Windows.Forms.DataGridViewTextBoxColumn Column3;
        private System.Windows.Forms.DataGridViewTextBoxColumn Column4;
        private System.Windows.Forms.DataGridViewTextBoxColumn Column5;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.Panel panel2;
        private System.Windows.Forms.TextBox ClientNameTb;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.TextBox ItPriceTb;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Button ResetBtn;
        private System.Windows.Forms.Button AddToBillBtn;
        private System.Windows.Forms.TextBox ItQtyTb;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.TextBox ItNameTb;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.Label label9;
        private Guna.UI2.WinForms.Guna2DataGridView ItemDGV;
        private System.Windows.Forms.Label TotalLbl;
        private System.Windows.Forms.Button button1;
        private System.Drawing.Printing.PrintDocument printDocument1;
        private System.Windows.Forms.PrintPreviewDialog printPreviewDialog1;
    }
}