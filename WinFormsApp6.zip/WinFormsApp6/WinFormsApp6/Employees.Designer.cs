﻿namespace WinFormsApp6
{
    partial class Employees
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Employees));
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle1 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle2 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle3 = new System.Windows.Forms.DataGridViewCellStyle();
            panel1 = new System.Windows.Forms.Panel();
            pictureBox2 = new System.Windows.Forms.PictureBox();
            label1 = new System.Windows.Forms.Label();
            label2 = new System.Windows.Forms.Label();
            panel3 = new System.Windows.Forms.Panel();
            flowLayoutPanel1 = new System.Windows.Forms.FlowLayoutPanel();
            label8 = new System.Windows.Forms.Label();
            EmployeesDGV = new Guna.UI2.WinForms.Guna2DataGridView();
            panel2 = new System.Windows.Forms.Panel();
            EmpcodeTb = new System.Windows.Forms.TextBox();
            label10 = new System.Windows.Forms.Label();
            EmpPassTb = new System.Windows.Forms.TextBox();
            button2 = new System.Windows.Forms.Button();
            button1 = new System.Windows.Forms.Button();
            button4 = new System.Windows.Forms.Button();
            button3 = new System.Windows.Forms.Button();
            label6 = new System.Windows.Forms.Label();
            EmpAddTb = new System.Windows.Forms.TextBox();
            label5 = new System.Windows.Forms.Label();
            EmpPhoneTb = new System.Windows.Forms.TextBox();
            label4 = new System.Windows.Forms.Label();
            EmpNameTb = new System.Windows.Forms.TextBox();
            label3 = new System.Windows.Forms.Label();
            label7 = new System.Windows.Forms.Label();
            panel1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)pictureBox2).BeginInit();
            panel3.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)EmployeesDGV).BeginInit();
            panel2.SuspendLayout();
            SuspendLayout();
            // 
            // panel1
            // 
            panel1.BackColor = System.Drawing.Color.Tomato;
            panel1.Controls.Add(pictureBox2);
            panel1.Controls.Add(label1);
            panel1.Dock = System.Windows.Forms.DockStyle.Top;
            panel1.Location = new System.Drawing.Point(0, 0);
            panel1.Name = "panel1";
            panel1.Size = new System.Drawing.Size(1652, 120);
            panel1.TabIndex = 5;
            // 
            // pictureBox2
            // 
            pictureBox2.Image = (System.Drawing.Image)resources.GetObject("pictureBox2.Image");
            pictureBox2.Location = new System.Drawing.Point(1604, 0);
            pictureBox2.Name = "pictureBox2";
            pictureBox2.Size = new System.Drawing.Size(48, 43);
            pictureBox2.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            pictureBox2.TabIndex = 20;
            pictureBox2.TabStop = false;
            pictureBox2.Click += pictureBox2_Click;
            // 
            // label1
            // 
            label1.AutoSize = true;
            label1.Font = new System.Drawing.Font("Century Gothic", 18F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            label1.ForeColor = System.Drawing.Color.White;
            label1.Location = new System.Drawing.Point(527, 41);
            label1.Name = "label1";
            label1.Size = new System.Drawing.Size(489, 43);
            label1.TabIndex = 2;
            label1.Text = "GROCERY SHOP SOFTWARE";
            // 
            // label2
            // 
            label2.AutoSize = true;
            label2.BackColor = System.Drawing.Color.Tomato;
            label2.Font = new System.Drawing.Font("Century Gothic", 14F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            label2.ForeColor = System.Drawing.Color.Black;
            label2.Location = new System.Drawing.Point(1530, 879);
            label2.Name = "label2";
            label2.Size = new System.Drawing.Size(110, 34);
            label2.TabIndex = 46;
            label2.Text = "Logout";
            label2.Click += label2_Click;
            // 
            // panel3
            // 
            panel3.BackColor = System.Drawing.Color.Tomato;
            panel3.Controls.Add(flowLayoutPanel1);
            panel3.Location = new System.Drawing.Point(356, 162);
            panel3.Name = "panel3";
            panel3.Size = new System.Drawing.Size(150, 4);
            panel3.TabIndex = 41;
            // 
            // flowLayoutPanel1
            // 
            flowLayoutPanel1.Location = new System.Drawing.Point(166, 1);
            flowLayoutPanel1.Name = "flowLayoutPanel1";
            flowLayoutPanel1.Size = new System.Drawing.Size(300, 150);
            flowLayoutPanel1.TabIndex = 0;
            // 
            // label8
            // 
            label8.AutoSize = true;
            label8.Font = new System.Drawing.Font("Century Gothic", 14F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            label8.ForeColor = System.Drawing.Color.Red;
            label8.Location = new System.Drawing.Point(659, 132);
            label8.Name = "label8";
            label8.Size = new System.Drawing.Size(86, 34);
            label8.TabIndex = 45;
            label8.Text = "Items";
            label8.Click += label8_Click;
            // 
            // EmployeesDGV
            // 
            dataGridViewCellStyle1.BackColor = System.Drawing.Color.White;
            EmployeesDGV.AlternatingRowsDefaultCellStyle = dataGridViewCellStyle1;
            EmployeesDGV.BackgroundColor = System.Drawing.SystemColors.Control;
            dataGridViewCellStyle2.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle2.BackColor = System.Drawing.Color.FromArgb(100, 88, 255);
            dataGridViewCellStyle2.Font = new System.Drawing.Font("Segoe UI", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            dataGridViewCellStyle2.ForeColor = System.Drawing.Color.White;
            dataGridViewCellStyle2.SelectionBackColor = System.Drawing.SystemColors.Highlight;
            dataGridViewCellStyle2.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle2.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            EmployeesDGV.ColumnHeadersDefaultCellStyle = dataGridViewCellStyle2;
            EmployeesDGV.ColumnHeadersHeight = 27;
            EmployeesDGV.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.EnableResizing;
            dataGridViewCellStyle3.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle3.BackColor = System.Drawing.Color.White;
            dataGridViewCellStyle3.Font = new System.Drawing.Font("Segoe UI", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            dataGridViewCellStyle3.ForeColor = System.Drawing.Color.FromArgb(71, 69, 94);
            dataGridViewCellStyle3.SelectionBackColor = System.Drawing.Color.FromArgb(231, 229, 255);
            dataGridViewCellStyle3.SelectionForeColor = System.Drawing.Color.FromArgb(71, 69, 94);
            dataGridViewCellStyle3.WrapMode = System.Windows.Forms.DataGridViewTriState.False;
            EmployeesDGV.DefaultCellStyle = dataGridViewCellStyle3;
            EmployeesDGV.GridColor = System.Drawing.Color.FromArgb(231, 229, 255);
            EmployeesDGV.Location = new System.Drawing.Point(42, 505);
            EmployeesDGV.Name = "EmployeesDGV";
            EmployeesDGV.RowHeadersVisible = false;
            EmployeesDGV.RowHeadersWidth = 62;
            EmployeesDGV.RowTemplate.Height = 33;
            EmployeesDGV.Size = new System.Drawing.Size(1598, 360);
            EmployeesDGV.TabIndex = 44;
            EmployeesDGV.ThemeStyle.AlternatingRowsStyle.BackColor = System.Drawing.Color.White;
            EmployeesDGV.ThemeStyle.AlternatingRowsStyle.Font = null;
            EmployeesDGV.ThemeStyle.AlternatingRowsStyle.ForeColor = System.Drawing.Color.Empty;
            EmployeesDGV.ThemeStyle.AlternatingRowsStyle.SelectionBackColor = System.Drawing.Color.Empty;
            EmployeesDGV.ThemeStyle.AlternatingRowsStyle.SelectionForeColor = System.Drawing.Color.Empty;
            EmployeesDGV.ThemeStyle.BackColor = System.Drawing.SystemColors.Control;
            EmployeesDGV.ThemeStyle.GridColor = System.Drawing.Color.FromArgb(231, 229, 255);
            EmployeesDGV.ThemeStyle.HeaderStyle.BackColor = System.Drawing.Color.Tomato;
            EmployeesDGV.ThemeStyle.HeaderStyle.BorderStyle = System.Windows.Forms.DataGridViewHeaderBorderStyle.None;
            EmployeesDGV.ThemeStyle.HeaderStyle.Font = new System.Drawing.Font("Century Gothic", 14F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            EmployeesDGV.ThemeStyle.HeaderStyle.ForeColor = System.Drawing.Color.White;
            EmployeesDGV.ThemeStyle.HeaderStyle.HeaightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.EnableResizing;
            EmployeesDGV.ThemeStyle.HeaderStyle.Height = 27;
            EmployeesDGV.ThemeStyle.ReadOnly = false;
            EmployeesDGV.ThemeStyle.RowsStyle.BackColor = System.Drawing.Color.White;
            EmployeesDGV.ThemeStyle.RowsStyle.BorderStyle = System.Windows.Forms.DataGridViewCellBorderStyle.SingleHorizontal;
            EmployeesDGV.ThemeStyle.RowsStyle.Font = new System.Drawing.Font("Segoe UI", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            EmployeesDGV.ThemeStyle.RowsStyle.ForeColor = System.Drawing.Color.FromArgb(71, 69, 94);
            EmployeesDGV.ThemeStyle.RowsStyle.Height = 33;
            EmployeesDGV.ThemeStyle.RowsStyle.SelectionBackColor = System.Drawing.Color.FromArgb(231, 229, 255);
            EmployeesDGV.ThemeStyle.RowsStyle.SelectionForeColor = System.Drawing.Color.FromArgb(71, 69, 94);
            EmployeesDGV.CellContentClick += EmployeesDGV_CellContentClick;
            // 
            // panel2
            // 
            panel2.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            panel2.Controls.Add(EmpcodeTb);
            panel2.Controls.Add(label10);
            panel2.Controls.Add(EmpPassTb);
            panel2.Controls.Add(button2);
            panel2.Controls.Add(button1);
            panel2.Controls.Add(button4);
            panel2.Controls.Add(button3);
            panel2.Controls.Add(label6);
            panel2.Controls.Add(EmpAddTb);
            panel2.Controls.Add(label5);
            panel2.Controls.Add(EmpPhoneTb);
            panel2.Controls.Add(label4);
            panel2.Controls.Add(EmpNameTb);
            panel2.Controls.Add(label3);
            panel2.Location = new System.Drawing.Point(0, 204);
            panel2.Name = "panel2";
            panel2.Size = new System.Drawing.Size(1652, 251);
            panel2.TabIndex = 43;
            panel2.Paint += panel2_Paint;
            // 
            // EmpcodeTb
            // 
            EmpcodeTb.Location = new System.Drawing.Point(1266, 49);
            EmpcodeTb.Name = "EmpcodeTb";
            EmpcodeTb.Size = new System.Drawing.Size(243, 31);
            EmpcodeTb.TabIndex = 22;
            EmpcodeTb.TextChanged += textBox1_TextChanged;
            // 
            // label10
            // 
            label10.AutoSize = true;
            label10.Font = new System.Drawing.Font("Century Gothic", 14F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            label10.ForeColor = System.Drawing.Color.Red;
            label10.Location = new System.Drawing.Point(1266, 12);
            label10.Name = "label10";
            label10.Size = new System.Drawing.Size(247, 34);
            label10.TabIndex = 21;
            label10.Text = "Employees Code";
            // 
            // EmpPassTb
            // 
            EmpPassTb.Location = new System.Drawing.Point(962, 49);
            EmpPassTb.Name = "EmpPassTb";
            EmpPassTb.Size = new System.Drawing.Size(243, 31);
            EmpPassTb.TabIndex = 19;
            // 
            // button2
            // 
            button2.BackColor = System.Drawing.Color.Tomato;
            button2.FlatAppearance.BorderSize = 0;
            button2.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            button2.Font = new System.Drawing.Font("Century Gothic", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            button2.Location = new System.Drawing.Point(490, 153);
            button2.Name = "button2";
            button2.Size = new System.Drawing.Size(173, 60);
            button2.TabIndex = 18;
            button2.Text = "Edit";
            button2.UseVisualStyleBackColor = false;
            button2.Click += button2_Click_1;
            // 
            // button1
            // 
            button1.BackColor = System.Drawing.Color.Tomato;
            button1.FlatAppearance.BorderSize = 0;
            button1.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            button1.Font = new System.Drawing.Font("Century Gothic", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            button1.Location = new System.Drawing.Point(245, 153);
            button1.Name = "button1";
            button1.Size = new System.Drawing.Size(173, 60);
            button1.TabIndex = 17;
            button1.Text = "Save";
            button1.UseVisualStyleBackColor = false;
            button1.Click += button1_Click_1;
            // 
            // button4
            // 
            button4.BackColor = System.Drawing.Color.Tomato;
            button4.FlatAppearance.BorderSize = 0;
            button4.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            button4.Font = new System.Drawing.Font("Century Gothic", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            button4.Location = new System.Drawing.Point(993, 153);
            button4.Name = "button4";
            button4.Size = new System.Drawing.Size(173, 60);
            button4.TabIndex = 16;
            button4.Text = "Clear";
            button4.UseVisualStyleBackColor = false;
            button4.Click += button4_Click_1;
            // 
            // button3
            // 
            button3.BackColor = System.Drawing.Color.Tomato;
            button3.FlatAppearance.BorderSize = 0;
            button3.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            button3.Font = new System.Drawing.Font("Century Gothic", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            button3.Location = new System.Drawing.Point(737, 153);
            button3.Name = "button3";
            button3.Size = new System.Drawing.Size(173, 60);
            button3.TabIndex = 15;
            button3.Text = "Delete";
            button3.UseVisualStyleBackColor = false;
            button3.Click += button3_Click_1;
            // 
            // label6
            // 
            label6.AutoSize = true;
            label6.Font = new System.Drawing.Font("Century Gothic", 14F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            label6.ForeColor = System.Drawing.Color.Red;
            label6.Location = new System.Drawing.Point(962, 12);
            label6.Name = "label6";
            label6.Size = new System.Drawing.Size(142, 34);
            label6.TabIndex = 14;
            label6.Text = "Password";
            // 
            // EmpAddTb
            // 
            EmpAddTb.Location = new System.Drawing.Point(633, 49);
            EmpAddTb.Name = "EmpAddTb";
            EmpAddTb.Size = new System.Drawing.Size(243, 31);
            EmpAddTb.TabIndex = 12;
            // 
            // label5
            // 
            label5.AutoSize = true;
            label5.Font = new System.Drawing.Font("Century Gothic", 14F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            label5.ForeColor = System.Drawing.Color.Red;
            label5.Location = new System.Drawing.Point(633, 12);
            label5.Name = "label5";
            label5.Size = new System.Drawing.Size(122, 34);
            label5.TabIndex = 11;
            label5.Text = "Address";
            // 
            // EmpPhoneTb
            // 
            EmpPhoneTb.Location = new System.Drawing.Point(324, 49);
            EmpPhoneTb.Name = "EmpPhoneTb";
            EmpPhoneTb.Size = new System.Drawing.Size(243, 31);
            EmpPhoneTb.TabIndex = 10;
            // 
            // label4
            // 
            label4.AutoSize = true;
            label4.Font = new System.Drawing.Font("Century Gothic", 14F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            label4.ForeColor = System.Drawing.Color.Red;
            label4.Location = new System.Drawing.Point(324, 12);
            label4.Name = "label4";
            label4.Size = new System.Drawing.Size(102, 34);
            label4.TabIndex = 9;
            label4.Text = "Phone";
            // 
            // EmpNameTb
            // 
            EmpNameTb.Location = new System.Drawing.Point(29, 49);
            EmpNameTb.Name = "EmpNameTb";
            EmpNameTb.Size = new System.Drawing.Size(243, 31);
            EmpNameTb.TabIndex = 8;
            // 
            // label3
            // 
            label3.AutoSize = true;
            label3.Font = new System.Drawing.Font("Century Gothic", 14F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            label3.ForeColor = System.Drawing.Color.Red;
            label3.Location = new System.Drawing.Point(29, 12);
            label3.Name = "label3";
            label3.Size = new System.Drawing.Size(99, 34);
            label3.TabIndex = 5;
            label3.Text = "Name";
            // 
            // label7
            // 
            label7.AutoSize = true;
            label7.Font = new System.Drawing.Font("Century Gothic", 14F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            label7.ForeColor = System.Drawing.Color.Red;
            label7.Location = new System.Drawing.Point(356, 125);
            label7.Name = "label7";
            label7.Size = new System.Drawing.Size(161, 34);
            label7.TabIndex = 42;
            label7.Text = "Employees";
            // 
            // Employees
            // 
            AutoScaleDimensions = new System.Drawing.SizeF(10F, 25F);
            AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            ClientSize = new System.Drawing.Size(1652, 928);
            Controls.Add(label2);
            Controls.Add(panel3);
            Controls.Add(label8);
            Controls.Add(EmployeesDGV);
            Controls.Add(panel2);
            Controls.Add(label7);
            Controls.Add(panel1);
            FormBorderStyle = System.Windows.Forms.FormBorderStyle.None;
            Name = "Employees";
            StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            Text = "Employees";
            Load += Employees_Load;
            panel1.ResumeLayout(false);
            panel1.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)pictureBox2).EndInit();
            panel3.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)EmployeesDGV).EndInit();
            panel2.ResumeLayout(false);
            panel2.PerformLayout();
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.PictureBox pictureBox2;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Panel panel3;
        private System.Windows.Forms.FlowLayoutPanel flowLayoutPanel1;
        private System.Windows.Forms.Label label8;
        private Guna.UI2.WinForms.Guna2DataGridView EmployeesDGV;
        private System.Windows.Forms.Panel panel2;
        private System.Windows.Forms.TextBox EmpcodeTb;
        private System.Windows.Forms.Label label10;
        private System.Windows.Forms.TextBox EmpPassTb;
        private System.Windows.Forms.Button button2;
        private System.Windows.Forms.Button button1;
        private System.Windows.Forms.Button button4;
        private System.Windows.Forms.Button button3;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.TextBox EmpAddTb;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.TextBox EmpPhoneTb;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.TextBox EmpNameTb;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label7;
    }
}