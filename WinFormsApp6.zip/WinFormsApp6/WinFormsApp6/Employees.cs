﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using Microsoft.Data.SqlClient;

namespace WinFormsApp6
{
    public partial class Employees : Form
    {
        private SqlConnection Con;
        private int key = 0;
        public Employees()
        {
            InitializeComponent();
            Con = new SqlConnection(@"Data Source=(LocalDB)\MSSQLLocalDB;AttachDbFilename=C:\Users\amarx\Documents\amar.mdf;Integrated Security=True;Connect Timeout=30;Encrypt=True");
            DisplayEmployees();
        }

        private void Employees_Load(object sender, EventArgs e)
        {

        }

        private void button1_Click(object sender, EventArgs e)
        {

        }

        private void button2_Click(object sender, EventArgs e)
        {

        }

        private void button3_Click(object sender, EventArgs e)
        {

        }

        private void button4_Click(object sender, EventArgs e)
        {

        }

        private void ItemDGV_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {

        }

        private void label9_Click(object sender, EventArgs e)
        {

        }

        private void button1_Click_1(object sender, EventArgs e)
        {
            if (string.IsNullOrEmpty(EmpNameTb.Text) || string.IsNullOrEmpty(EmpPhoneTb.Text) || string.IsNullOrEmpty(EmpAddTb.Text) || string.IsNullOrEmpty(EmpPassTb.Text) || string.IsNullOrEmpty(EmpcodeTb.Text))
            {
                MessageBox.Show("Missing Information");
            }
            else
            {
                try
                {
                    Con.Open();
                    string query = "INSERT INTO EmployeeTbl (EmpName, EmpPhone, EmpAdd, EmpPass, Itcode) VALUES (@EmpName, @EmpPhone, @EmpAdd, @EmpPass, @Itcode)";
                    SqlCommand cmd = new SqlCommand(query, Con);
                    cmd.Parameters.AddWithValue("@EmpName", EmpNameTb.Text);
                    cmd.Parameters.AddWithValue("@EmpPhone", EmpPhoneTb.Text);
                    cmd.Parameters.AddWithValue("@EmpAdd", EmpAddTb.Text);
                    cmd.Parameters.AddWithValue("@EmpPass", EmpPassTb.Text);
                    cmd.Parameters.AddWithValue("@Itcode", EmpcodeTb.Text);  // Add this line
                    cmd.ExecuteNonQuery();
                    MessageBox.Show("Employee Saved Successfully");
                    Con.Close();
                    DisplayEmployees();
                    Clear();
                }
                catch (Exception ex)
                {
                    MessageBox.Show(ex.Message);
                }
            }
        }
        private void Clear()
        {
            EmpNameTb.Text = "";
            EmpPhoneTb.Text = "";
            EmpAddTb.Text = "";
            EmpPassTb.Text = "";
            EmpcodeTb.Text = "";
        }
        private void DisplayEmployees()
        {
            Con.Open();
            string query = "SELECT * FROM EmployeeTbl";
            SqlCommand cmd = new SqlCommand(query, Con);
            SqlDataAdapter adapter = new SqlDataAdapter(cmd);
            DataSet ds = new DataSet();
            adapter.Fill(ds);
            EmployeesDGV.DataSource = ds.Tables[0];
            Con.Close();
        }
        private void label8_Click(object sender, EventArgs e)
        {

            items Obj = new items();
            Obj.Show();
            this.Hide();
        }

        private void label2_Click(object sender, EventArgs e)
        {
            Login Obj = new Login();

            Obj.Show();

            this.Hide();
        }

        private void pictureBox2_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }

        private void button2_Click_1(object sender, EventArgs e)
        {

            if (string.IsNullOrEmpty(EmpNameTb.Text) || string.IsNullOrEmpty(EmpPhoneTb.Text) || string.IsNullOrEmpty(EmpAddTb.Text) || string.IsNullOrEmpty(EmpPassTb.Text) || string.IsNullOrEmpty(EmpcodeTb.Text))
            {
                MessageBox.Show("Missing Information");
            }
            else
            {
                try
                {
                    Con.Open();
                    string query = "UPDATE EmployeeTbl SET EmpName=@EmpName, EmpPhone=@EmpPhone, EmpAdd=@EmpAdd, EmpPass=@EmpPass, Itcode=@Itcode WHERE EmpId=@EmpId";
                    SqlCommand cmd = new SqlCommand(query, Con);
                    cmd.Parameters.AddWithValue("@EmpName", EmpNameTb.Text);
                    cmd.Parameters.AddWithValue("@EmpPhone", EmpPhoneTb.Text);
                    cmd.Parameters.AddWithValue("@EmpAdd", EmpAddTb.Text);
                    cmd.Parameters.AddWithValue("@EmpPass", EmpPassTb.Text);
                    cmd.Parameters.AddWithValue("@Itcode", EmpcodeTb.Text);  // Add this line
                    cmd.Parameters.AddWithValue("@EmpId", key);
                    cmd.ExecuteNonQuery();
                    MessageBox.Show("Employee Updated Successfully");
                    Con.Close();
                    DisplayEmployees();
                    Clear();
                }
                catch (Exception ex)
                {
                    MessageBox.Show(ex.Message);
                }
            }
        }

        private void button3_Click_1(object sender, EventArgs e)
        {
            if (key == 0)
            {
                MessageBox.Show("Select Employee To Delete");
            }
            else
            {
                try
                {
                    Con.Open();
                    string query = "DELETE FROM EmployeeTbl WHERE EmpId=@EmpId";
                    SqlCommand cmd = new SqlCommand(query, Con);
                    cmd.Parameters.AddWithValue("@EmpId", key);
                    cmd.ExecuteNonQuery();
                    MessageBox.Show("Employee Deleted Successfully");
                    Con.Close();
                    DisplayEmployees();
                    Clear();
                }
                catch (Exception ex)
                {
                    MessageBox.Show(ex.Message);
                }
            }
        }

        private void button4_Click_1(object sender, EventArgs e)
        {
            Clear();
        }

        private void EmployeesDGV_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {
            if (e.RowIndex >= 0)
            {
                DataGridViewRow row = EmployeesDGV.Rows[e.RowIndex];
                EmpNameTb.Text = row.Cells[1].Value.ToString();
                EmpPhoneTb.Text = row.Cells[2].Value.ToString();
                EmpAddTb.Text = row.Cells[3].Value.ToString();
                EmpPassTb.Text = row.Cells[4].Value.ToString();
                EmpcodeTb.Text = row.Cells[5].Value.ToString();  // Add this line

                if (string.IsNullOrEmpty(EmpNameTb.Text))
                {
                    key = 0;
                }
                else
                {
                    key = Convert.ToInt32(row.Cells[0].Value.ToString());
                }
            }
        }

        private void panel2_Paint(object sender, PaintEventArgs e)
        {

        }

        private void textBox1_TextChanged(object sender, EventArgs e)
        {

        }
    }
}
