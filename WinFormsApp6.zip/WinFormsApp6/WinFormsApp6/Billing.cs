﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Drawing.Printing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using Microsoft.Data.SqlClient;

namespace WinFormsApp6
{
    public partial class Billing : Form
    {
        public Billing()
        {
            InitializeComponent();
            populate();
        }
        SqlConnection Con = new SqlConnection(@"Data Source=(LocalDB)\MSSQLLocalDB;AttachDbFilename=C:\Users\amarx\Documents\amar.mdf;Integrated Security=True;Connect Timeout=30;Encrypt=True");
        private void Billing_Load(object sender, EventArgs e)
        {

        }
        private void populate()

        {

            Con.Open();
            string query = "select * from ItemTbl";
            SqlDataAdapter sda = new SqlDataAdapter(query, Con);
            SqlCommandBuilder builder = new SqlCommandBuilder(sda);
            var ds = new DataSet();
            sda.Fill(ds);
            ItemDGV.DataSource = ds.Tables[0];
            Con.Close();
        }
        int n = 0, GrdTota1 = 0, Amount;
        private void AddToBillBtn_Click(object sender, EventArgs e)
        {
            if (ItQtyTb.Text == "" || Convert.ToInt32(ItQtyTb.Text) > stock)

            {
                MessageBox.Show("Enter Quantity");
            }
            else

            {
                int total = Convert.ToInt32(ItQtyTb.Text) * Convert.ToInt32(ItPriceTb.Text);
                DataGridViewRow newRow = new DataGridViewRow();
                newRow.CreateCells(BillDGV);
                newRow.Cells[0].Value = n + 1;
                newRow.Cells[1].Value = ItNameTb.Text;
                newRow.Cells[2].Value = ItPriceTb.Text;
                newRow.Cells[3].Value = ItQtyTb.Text;
                newRow.Cells[4].Value = total;
                BillDGV.Rows.Add(newRow);
                GrdTota1 = GrdTota1 + total;
                Amount GrdTotal;
                TotalLbl.Text = "Rs = " + GrdTota1;
                n++;
                UpdateItem();
                Reset();
            }
        }
        private void UpdateItem()

        {

            try

            {
                int newQty = stock - Convert.ToInt32(ItQtyTb.Text);
                Con.Open();
                string query = "Update ItemTbl set ItQty=" + newQty + "where ItId=" + Key + "; ";
                SqlCommand cmd = new SqlCommand(query, Con);
                cmd.ExecuteNonQuery();
                MessageBox.Show("Item Updated Successfully");
                Con.Close();
                populate();
                //Clear();

            }

            catch (Exception Ex)

            {
                MessageBox.Show(Ex.Message);
            }

        }
        private void Reset()

        {
            ItPriceTb.Text = "";
            ItQtyTb.Text = "";
            ClientNameTb.Text = "";
            ItNameTb.Text = "";
        }
        private void ResetBtn_Click(object sender, EventArgs e)
        {
            Reset();
        }
        int stock = 0, Key = 0;

        public string EmployeeName { get; private set; }

        private void ItemDGV_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {
            ItNameTb.Text = ItemDGV.SelectedRows[0].Cells[1].Value.ToString();

            ItPriceTb.Text = ItemDGV.SelectedRows[0].Cells[3].Value.ToString();

            if (ItNameTb.Text == "")

            {
                stock = 0;
                Key = 0;
            }
            else

            {
                stock = Convert.ToInt32(ItemDGV.SelectedRows[0].Cells[2].Value.ToString());
                Key = Convert.ToInt32(ItemDGV.SelectedRows[0].Cells[0].Value.ToString());
            }
        }

        private void button1_Click(object sender, EventArgs e)
        {
            if (string.IsNullOrEmpty(ClientNameTb.Text))
            {
                MessageBox.Show("Missing Information");
            }
            else
            {
                try
                {

                    Con.Open();
                    string query = "INSERT INTO BillTbl ( EName, ClientName, Amount) VALUES ( @EName, @ClientName, @Amount)";
                    using (SqlCommand cmd = new SqlCommand(query, Con))
                    {
                        cmd.Parameters.AddWithValue("@EId", EmployeeLbl.Text);
                        cmd.Parameters.AddWithValue("@EName", EmployeeLbl.Text);
                        cmd.Parameters.AddWithValue("@ClientName", ClientNameTb.Text);
                        cmd.Parameters.AddWithValue("@Amount", GrdTota1);
                        cmd.ExecuteNonQuery();
                    }
                    MessageBox.Show("Bill Saved Successfully");
                    Con.Close();
                    populate();
                }
                catch (Exception Ex)
                {
                    MessageBox.Show(Ex.Message);
                }

            }
            printPreviewDialog1.Document = printDocument1;
            if (printPreviewDialog1.ShowDialog() == DialogResult.OK)
            {
                printDocument1.Print();
            }
        }

        private void EmployeeLbl_Click(object sender, EventArgs e)
        {
            EmployeeLbl.Text = Login.EmployeeName;
        }
        private void Login_Load(object sender, EventArgs e)
        {
            if (!string.IsNullOrEmpty(EmployeeName))
            {
                EmployeeLbl.Text = EmployeeName;
            }
        }

        private void label9_Click(object sender, EventArgs e)
        {
            Login Obj = new Login();

            Obj.Show();

            this.Hide();
        }

        private void printPreviewDialog1_Load(object sender, EventArgs e)
        {

        }

        private void printDocument1_PrintPage(object sender, PrintPageEventArgs e)
        {
            Font headerFont = new Font("Arial", 16, FontStyle.Bold);
            Font subHeaderFont = new Font("Arial", 12, FontStyle.Bold);
            Font textFont = new Font("Arial", 10, FontStyle.Regular);

            e.Graphics.DrawString("Grocery Store Bill", headerFont, Brushes.Black, new Point(100, 20));
            e.Graphics.DrawString("Employee: " + EmployeeLbl.Text, subHeaderFont, Brushes.Black, new Point(100, 60));
            e.Graphics.DrawString("Client: " + ClientNameTb.Text, subHeaderFont, Brushes.Black, new Point(100, 100));
            e.Graphics.DrawString("Date: " + DateTime.Now.ToString("MM/dd/yyyy"), textFont, Brushes.Black, new Point(100, 140));

            e.Graphics.DrawString("No.", subHeaderFont, Brushes.Black, new Point(100, 180));
            e.Graphics.DrawString("Item Name", subHeaderFont, Brushes.Black, new Point(150, 180));
            e.Graphics.DrawString("Price", subHeaderFont, Brushes.Black, new Point(300, 180));
            e.Graphics.DrawString("Quantity", subHeaderFont, Brushes.Black, new Point(400, 180));
            e.Graphics.DrawString("Total", subHeaderFont, Brushes.Black, new Point(500, 180));

            int yPos = 210;
            foreach (DataGridViewRow row in BillDGV.Rows)
            {
                if (row.Cells[0].Value != null)
                {
                    e.Graphics.DrawString(row.Cells[0].Value?.ToString() ?? "", textFont, Brushes.Black, new Point(100, yPos));
                    e.Graphics.DrawString(row.Cells[1].Value?.ToString() ?? "", textFont, Brushes.Black, new Point(150, yPos));
                    e.Graphics.DrawString(row.Cells[2].Value?.ToString() ?? "", textFont, Brushes.Black, new Point(300, yPos));
                    e.Graphics.DrawString(row.Cells[3].Value?.ToString() ?? "", textFont, Brushes.Black, new Point(400, yPos));
                    e.Graphics.DrawString(row.Cells[4].Value?.ToString() ?? "", textFont, Brushes.Black, new Point(500, yPos));
                    yPos += 30;
                }
            }

            e.Graphics.DrawString("Grand Total: Rs " + GrdTota1, subHeaderFont, Brushes.Black, new Point(100, yPos + 30));
        }

        private void pictureBox1_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }

        private void BillDGV_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {

        }
    }
}
